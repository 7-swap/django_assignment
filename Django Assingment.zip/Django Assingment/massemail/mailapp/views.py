from django.shortcuts import render
from django.core.mail import send_mail,EmailMultiAlternatives
from django.conf import settings

# Create your views here.
def home(request):
    if request.method=='POST':
        sub=request.POST.get('subject')
        msg=request.POST.get('body')

        msg = EmailMultiAlternatives(sub, msg,settings.EMAIL_HOST_USER ,['vigakav930@dukeoo.com'])
        msg.attach('VoidMoon.jpg','/images')
        msg.send()

              
    return render(request,'mail.html')